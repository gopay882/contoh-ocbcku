function go(){   
setTimeout(function(){  
location.href='https://wa.me/628995295824'; 
 }, 000);    
}     
